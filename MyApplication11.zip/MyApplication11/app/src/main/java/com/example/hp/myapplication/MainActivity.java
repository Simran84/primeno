package com.example.hp.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText edit1;
    Button button;
    TextView text1;
    int temp=1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edit1=findViewById(R.id.ed1);
        button=findViewById(R.id.btn1);
        text1=findViewById(R.id.txt1);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              String a=  edit1.getText().toString();
              int b=Integer.parseInt(a);
              for(int i=2;i<=b/2;i++){
                  //temp=1;
                  temp=b%i;
                  if(temp==0){
                    //  text1.setText("not a prime no");
                      break;
                  }

                /* String value= Integer.toString(i);
                  text1.setText(text1.getText().toString()+value);*/
              }
                if(temp==0){
                    text1.setText("not a prime no");

                }
                else
                {
                    text1.setText("prime no");
                }
            }
        });


    }
}
